from regis import *

@bot.on(events.NewMessage(pattern=r"(?:.regis|/regis|/start)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline(" REGIST ","registrasi"),
Button.inline(" EXTEND ","perpanjang")],
[Button.inline(" CHECK","cekip"),
Button.inline(" DELETE ","deleteip")],
[Button.inline(" Join Grup ","https://t.me/HadesxGroup")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		sh = f' curl -sS https://raw.githubusercontent.com/hadesxv2/ip/main/ip | grep "###" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")

		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**☘️ Hadesx Autoscript Premium ☘️**
━━━━━━━━━━━━━━━━━━━━━━━ 
Halo Tuan {sender.first_name}
Selamat Datang Di Layanan Script premium

List Harga Script :** 
🔰**1 BULAN 10k**
🔰**2 BULAN 20k**
🔰**3 BULAN 30K**
🔰**LIFE TIME 1IP 55K**

Note:
**- Anda harus memiliki akses Terbalih Dahulu**
**- Hubungi Admin Agar Anda Mempunyai Akses**.
━━━━━━━━━━━━━━━━━━━━━━━ 
**» Order :** @iHadesx
**» Total Pelanggan :** `{ssh.strip()}`
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)

